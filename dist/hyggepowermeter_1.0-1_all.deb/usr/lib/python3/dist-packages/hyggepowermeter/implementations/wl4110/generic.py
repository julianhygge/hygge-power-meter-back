from pymodbus.client.sync import ModbusSerialClient
from pymodbus.constants import Endian
from pymodbus.payload import BinaryPayloadDecoder

# Create a Modbus RTU client instance
client = ModbusSerialClient(
    method='rtu',
    port='/dev/MAX0',  # Replace with your device's serial port
    baudrate=9600,
    bytesize=8,
    parity='E',
    stopbits=1,
    timeout=1
)

# Connect to the Modbus device
if not client.connect():
    print("Failed to connect to Modbus device")
    exit(1)

# Define the starting and ending register addresses
START_ADDR = 0
END_ADDR = 200

# Read all the Modbus registers
result = client.read_holding_registers(
    address=START_ADDR,
    count=END_ADDR - START_ADDR + 1,
    unit=1  # Replace with your device's Modbus address
)

# Disconnect from the Modbus device
client.close()

# Check if the read operation was successful
if not result.isError():
    # Decode the binary payload into a list of values
    decoder = BinaryPayloadDecoder.fromRegisters(
        result.registers, byteorder=Endian.Big, wordorder=Endian.Big
    )
    values = decoder.decode_32bit_float()  # Change to decode as per data type

    # Print the values
    for i, value in enumerate(values):
        print(f"Register {START_ADDR + i}: {value}")
else:
    print(f"Failed to read Modbus registers: {result}")