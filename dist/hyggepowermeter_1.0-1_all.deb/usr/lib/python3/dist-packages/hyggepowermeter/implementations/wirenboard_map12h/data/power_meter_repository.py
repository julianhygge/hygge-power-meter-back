import sqlite3


class Map12Repository:
    def __init__(self, db):
        self.db = db + ".db"
        self.__create_table()

    def __create_table(self):
        conn = sqlite3.connect(self.db)
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS meter_readings (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            device_id INTEGER,
                            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                            rms_l1_voltage,
                            rms_l2_voltage,
                            rms_l3_voltage,
                            rms_l1_current_ch1,
                            rms_l2_current_ch1,
                            rms_l3_current_ch1,
                            phase_angle_l1_ch1,
                            phase_angle_l2_ch1,
                            phase_angle_l3_ch1,
                            total_active_power_ch1,
                            total_reactive_power_ch1,
                            total_apparent_power_ch1,
                            rms_l1_current_ch2,
                            rms_l2_current_ch2,
                            rms_l3_current_ch2,
                            phase_angle_l1_ch2,
                            phase_angle_l2_ch2,
                            phase_angle_l3_ch2,
                            total_active_power_ch2,
                            total_reactive_power_ch2,
                            total_apparent_power_ch2,
                            rms_l1_current_ch3,
                            rms_l2_current_ch3,
                            rms_l3_current_ch3,
                            phase_angle_l1_ch3,
                            phase_angle_l2_ch3,
                            phase_angle_l3_ch3,
                            total_active_power_ch3,
                            total_reactive_power_ch3,
                            total_apparent_power_ch3,
                            rms_l1_current_ch4,
                            rms_l2_current_ch4,
                            rms_l3_current_ch4,
                            phase_angle_l1_ch4,
                            phase_angle_l2_ch4,
                            phase_angle_l3_ch4,
                            total_active_power_ch4,
                            total_reactive_power_ch4,
                            total_apparent_power_ch4,
                            consumption_active_ch1,
                            consumption_reactive_ch1,
                            consumption_apparent_ch1,
                            consumption_active_ch2,
                            consumption_reactive_ch2,
                            consumption_apparent_ch2,
                            consumption_active_ch3,
                            consumption_reactive_ch3,
                            consumption_apparent_ch3,
                            consumption_active_ch4,
                            consumption_reactive_ch4,
                            consumption_apparent_ch4)''')
        conn.close()

    def save(self, readings, device_id):
        conn = sqlite3.connect(self.db)
        readings['device_id'] = device_id
        columns = ', '.join(readings.keys())
        placeholders = ', '.join('?' * len(readings))
        sql = f"INSERT INTO meter_readings ({columns}) VALUES ({placeholders})"
        cursor = conn.cursor()
        cursor.execute(sql, tuple(readings.values()))
        conn.commit()
        conn.close()

    def read_all_values(self, device_id):
        conn = sqlite3.connect(self.db)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM meter_readings WHERE device_id = ?', (device_id,))
        rows = cursor.fetchall()
        columns = [description[0] for description in cursor.description]
        result = [dict(zip(columns, row)) for row in rows]
        return result
